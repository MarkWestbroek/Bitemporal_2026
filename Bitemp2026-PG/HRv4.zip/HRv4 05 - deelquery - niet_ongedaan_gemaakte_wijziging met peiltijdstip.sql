-- wijzigingen tot en met peiltijdstip (formeel)
SELECT *
  FROM niet_ongedaan_gemaakte_wijzigingen
 WHERE registratie_tijdstip <= 't1'
delete from wijziging;
delete from o;
delete from registratie;